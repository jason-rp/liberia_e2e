﻿namespace Liberia_E2E.Model
{
    public class PostModel
    {
        public string id { get; set; }

        public string title { get; set; }

        public string author { get; set; }
    }
}
